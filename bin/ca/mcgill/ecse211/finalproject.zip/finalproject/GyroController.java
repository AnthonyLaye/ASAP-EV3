package ca.mcgill.ecse211.finalproject;

public interface GyroController {
	
	public int readAngle();

}
